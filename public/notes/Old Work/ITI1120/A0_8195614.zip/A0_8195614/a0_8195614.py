# Course:  IT1 1120 
# A1
# McDonald, John (Brennan)
# 8195614

print("Printing from a file.")